package com.tma.controller;

import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.text.SimpleDateFormat;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tma.entities.Candidate;
import com.tma.entities.Manager;
import com.tma.service.CandidateService;
import com.tma.service.ManagerService;
import com.tma.validator.CandidateValidator;

@EnableWebMvc
@Controller
@RequestMapping(value = "/candidate**")
public class CandidateController {

	@Autowired(required = true)
	private ManagerService managerService;
	@Autowired(required = true)
	private CandidateService candidateService;
//	@Autowired(required = true)
//	private CandidateValidator candidateValidator;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listCandidate", candidateService.findAll());
		return "listCandidate";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.addAttribute("candidate", new Candidate());
		// modelMap.addAttribute("listManager", managerService.findAll());

		return "addCandidate";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "candidate") @Valid Candidate candidate, BindingResult bindingResult) {
		CandidateValidator candidateValidator = new CandidateValidator();
		candidateValidator.validate(candidate, bindingResult);

		if (bindingResult.hasErrors()) {
			return "addCandidate";
		} else {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String name = auth.getName();
			Manager m = this.managerService.findManagerbyUserName(name);
			candidate.setManager(m);
			// candidateService.create(candidate);
			candidateService.create(candidate);
			return "redirect:/candidate.html";
		}
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		candidateService.remove(candidateService.find(id));
		return "redirect:/candidate.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.addAttribute("candidate", candidateService.find(id));
		// modelMap.addAttribute("listManager", managerService.findAll());
		return "editCandidate";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "candidate") @Valid Candidate candidate, BindingResult bindingResult,
			final RedirectAttributes redirectAttributes) {
		CandidateValidator candidateValidator = new CandidateValidator();
		candidateValidator.validate(candidate, bindingResult);
		if (bindingResult.hasErrors()) {
			// int id = candidate.getId();

			return "editCandidate";
		} else {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String name = auth.getName();
			Manager m = this.managerService.findManagerbyUserName(name);
			candidate.setManager(m);
			candidateService.edit(candidate);
			redirectAttributes.addFlashAttribute("message", "Save Applicant Successful");
			return "redirect:/candidate.html";
		}
	}

	@InitBinder
	protected void iinitBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

//	@InitBinder
//	protected void initBinder(WebDataBinder dataBinder) {
//
//		// Form target
//		Object target = dataBinder.getTarget();
//		if (target == null) {
//			return;
//		}
//		System.out.println("Target=" + target);
//
//		if (target.getClass() == Candidate.class) {
//			dataBinder.setValidator(candidateValidator);
//		}
//	}
}
