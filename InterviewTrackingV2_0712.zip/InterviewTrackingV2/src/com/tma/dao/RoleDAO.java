package com.tma.dao;

import java.util.List;

import com.tma.entities.Role;

public interface RoleDAO {
	public List<Role> fillAll();
}
