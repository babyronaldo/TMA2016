package com.tma.validator;

import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import org.springframework.validation.Validator;

import com.tma.entities.Candidate;

//@Component
public class CandidateValidator implements Validator {
	private EmailValidator emailValidator = EmailValidator.getInstance();

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return Candidate.class.equals(arg0);
	}

	@Override
	public void validate(Object target, Errors errors) {

		// TODO Auto-generated method stub
		Candidate candidate = (Candidate) target;
		if (!emailValidator.isValid(candidate.getEmail())) {
			// Error in email field.
			// Lỗi trường email.
			errors.rejectValue("email", "Error.candidate.email");
		}
	}

}
